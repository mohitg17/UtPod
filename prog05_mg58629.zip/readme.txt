Use make to compile the files;
Run ./test to run the program;
Reads from an input file ("test.txt");
